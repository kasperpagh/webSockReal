Open in WebStorm

In he Terminal type:
npm init
bower init


If you have not yet installed Bower type npm install --g bower first